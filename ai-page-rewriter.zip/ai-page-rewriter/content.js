// AI Page Rewriter - Content Script
// Extracts visible text elements and replaces them with rewritten versions

// Store original text for reset functionality
const originalTexts = new Map();

// Selectors for text elements we want to rewrite
const TEXT_SELECTORS = [
  "h1", "h2", "h3", "h4", "h5", "h6",
  "p",
  "li",
  "a",
  "button",
  "span",
  "label",
  "td", "th",
  "figcaption",
  "blockquote",
];

// Elements to skip
const SKIP_SELECTORS = [
  "script", "style", "noscript", "iframe", "svg",
  "input", "textarea", "select",
  "code", "pre",
  "[contenteditable='true']",
];

/**
 * Check if an element is visible
 */
function isVisible(element) {
  if (!element) return false;
  
  const style = window.getComputedStyle(element);
  if (style.display === "none" || style.visibility === "hidden" || style.opacity === "0") {
    return false;
  }
  
  const rect = element.getBoundingClientRect();
  if (rect.width === 0 || rect.height === 0) {
    return false;
  }
  
  return true;
}

/**
 * Check if element should be skipped
 */
function shouldSkip(element) {
  // Skip if matches skip selectors
  for (const selector of SKIP_SELECTORS) {
    if (element.matches(selector)) return true;
    if (element.closest(selector)) return true;
  }
  
  // Skip navigation elements (usually don't want to rewrite nav)
  if (element.closest("nav")) return true;
  
  // Skip footer (often has legal text)
  if (element.closest("footer")) return true;
  
  // Skip header nav items (but not hero headlines)
  if (element.closest("header") && element.matches("a, button, span")) return true;
  
  return false;
}

/**
 * Get clean text content from an element (direct text only, not children)
 */
function getDirectText(element) {
  let text = "";
  
  for (const node of element.childNodes) {
    if (node.nodeType === Node.TEXT_NODE) {
      text += node.textContent;
    }
  }
  
  return text.trim();
}

/**
 * Extract text elements from the page
 */
function extractTextElements() {
  const elements = [];
  let index = 0;
  
  for (const selector of TEXT_SELECTORS) {
    const matches = document.querySelectorAll(selector);
    
    for (const element of matches) {
      if (!isVisible(element)) continue;
      if (shouldSkip(element)) continue;
      
      // Get text content
      const text = element.innerText?.trim();
      if (!text || text.length < 3) continue;
      
      // Skip if too long (probably not a headline/copy element)
      if (text.length > 1000) continue;
      
      // Skip if already processed
      if (originalTexts.has(element)) continue;
      
      // Store reference for later
      const tagName = element.tagName.toLowerCase();
      
      elements.push({
        index,
        tagName,
        text,
        element, // Keep reference but don't send to popup
      });
      
      index++;
    }
  }
  
  return elements;
}

/**
 * Replace text in elements
 */
function replaceTextElements(rewrittenTexts) {
  // Build a map of index -> rewritten text
  const rewriteMap = new Map();
  for (const item of rewrittenTexts) {
    rewriteMap.set(item.index, item.text);
  }
  
  // Get current elements (same order as extraction)
  const elements = [];
  let index = 0;
  
  for (const selector of TEXT_SELECTORS) {
    const matches = document.querySelectorAll(selector);
    
    for (const element of matches) {
      if (!isVisible(element)) continue;
      if (shouldSkip(element)) continue;
      
      const text = element.innerText?.trim();
      if (!text || text.length < 3) continue;
      if (text.length > 1000) continue;
      
      elements.push({ index, element });
      index++;
    }
  }
  
  // Apply rewrites
  let appliedCount = 0;
  
  for (const { index, element } of elements) {
    if (rewriteMap.has(index)) {
      const newText = rewriteMap.get(index);
      
      // Store original if not already stored
      if (!originalTexts.has(element)) {
        originalTexts.set(element, element.innerText);
      }
      
      // Replace text
      element.innerText = newText;
      appliedCount++;
    }
  }
  
  return appliedCount;
}

/**
 * Reset all text to original
 */
function resetTextElements() {
  let resetCount = 0;
  
  for (const [element, originalText] of originalTexts) {
    if (document.contains(element)) {
      element.innerText = originalText;
      resetCount++;
    }
  }
  
  originalTexts.clear();
  return resetCount;
}

// ============================================================
// MESSAGE HANDLER
// ============================================================

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log("Content script received:", request.action);
  
  if (request.action === "extractText") {
    try {
      const elements = extractTextElements();
      
      // Send only serializable data (not element references)
      const serializableElements = elements.map(({ index, tagName, text }) => ({
        index,
        tagName,
        text,
      }));
      
      console.log(`Extracted ${serializableElements.length} elements`);
      sendResponse({ success: true, elements: serializableElements });
    } catch (error) {
      console.error("Extract error:", error);
      sendResponse({ success: false, error: error.message });
    }
  }
  
  if (request.action === "replaceText") {
    try {
      const count = replaceTextElements(request.rewrittenTexts);
      console.log(`Replaced ${count} elements`);
      sendResponse({ success: true, count });
    } catch (error) {
      console.error("Replace error:", error);
      sendResponse({ success: false, error: error.message });
    }
  }
  
  if (request.action === "resetText") {
    try {
      const count = resetTextElements();
      console.log(`Reset ${count} elements`);
      sendResponse({ success: true, count });
    } catch (error) {
      console.error("Reset error:", error);
      sendResponse({ success: false, error: error.message });
    }
  }
  
  return true; // Keep message channel open for async response
});

console.log("AI Page Rewriter content script loaded");
