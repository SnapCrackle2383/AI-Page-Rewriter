// Content script for AI Page Rewriter
// Handles text extraction, storage, and replacement on the webpage

(function () {
  // Store original text mapped by element index
  let originalTexts = new Map();
  let textElements = [];

  // Selectors for visible text elements
  const SELECTORS = "h1, h2, h3, p, li";

  /**
   * Check if an element is visible in the viewport
   */
  function isVisible(el) {
    const style = window.getComputedStyle(el);
    return (
      style.display !== "none" &&
      style.visibility !== "hidden" &&
      style.opacity !== "0" &&
      el.offsetParent !== null
    );
  }

  /**
   * Extract visible text elements from the page
   * Returns array of { index, tagName, text }
   */
  function extractTextElements() {
    textElements = [];
    originalTexts.clear();

    const elements = document.querySelectorAll(SELECTORS);

    elements.forEach((el, index) => {
      if (isVisible(el) && el.innerText.trim().length > 0) {
        // Store original text
        originalTexts.set(index, el.innerText);

        textElements.push({
          index: index,
          element: el,
          tagName: el.tagName.toLowerCase(),
          text: el.innerText.trim(),
        });
      }
    });

    return textElements.map(({ index, tagName, text }) => ({
      index,
      tagName,
      text,
    }));
  }

  /**
   * Replace text in elements with rewritten versions
   * @param {Array} rewrittenTexts - Array of { index, text }
   */
  function replaceTexts(rewrittenTexts) {
    rewrittenTexts.forEach(({ index, text }) => {
      const elementData = textElements.find((el) => el.index === index);
      if (elementData && elementData.element) {
        elementData.element.innerText = text;
      }
    });
  }

  /**
   * Restore all elements to their original text
   */
  function restoreOriginalTexts() {
    originalTexts.forEach((originalText, index) => {
      const elementData = textElements.find((el) => el.index === index);
      if (elementData && elementData.element) {
        elementData.element.innerText = originalText;
      }
    });
  }

  // Listen for messages from the popup
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "extractText") {
      const extracted = extractTextElements();
      sendResponse({ success: true, elements: extracted });
    } else if (request.action === "replaceText") {
      replaceTexts(request.rewrittenTexts);
      sendResponse({ success: true });
    } else if (request.action === "resetText") {
      restoreOriginalTexts();
      sendResponse({ success: true });
    }

    // Return true to indicate async response
    return true;
  });
})();

