# AI Page Rewriter

A Chrome extension that rewrites webpage copy using Claude AI. Turns vague, institutional marketing-speak into clear, conversion-focused text.

## What it does

- Extracts visible text from any webpage (h1, h2, h3, p, li)
- Rewrites headlines, body copy, and CTAs for clarity and conversion
- Analyzes the site type to calibrate rewriting intensity
- Preserves DOM structure — see changes in place instantly
- Reset button to restore original text

## Modes

| Mode | Goal |
|------|------|
| **Conversion** | Maximize action-taking. Lead with outcomes. |
| **Clarity** | Maximize comprehension. Front-load information. |
| **Trust** | Maximize credibility. Specific beats impressive. |
| **Informal** | Sound natural and direct. Reduce corporate stiffness. |
| **Formal** | Professional, risk-aware audience. Precise language. |
| **Hype** | Emphasize momentum and excitement. |

## Setup

### 1. Get a Claude API key

Go to [console.anthropic.com](https://console.anthropic.com) and create an API key.

### 2. Install the extension

1. Download or clone this repo
2. Open Chrome and go to `chrome://extensions`
3. Enable "Developer mode" (top right)
4. Click "Load unpacked" and select this folder

### 3. Add your API key

Click the extension icon, paste your API key in the field at the top, and click Save.

## Usage

1. Navigate to any webpage
2. Click the extension icon
3. Select a rewrite mode
4. (Optional) Add context like "Target audience: B2B SaaS buyers"
5. Click "Rewrite Page"
6. Review changes on the page
7. Click "Reset" to restore original text

## How it works

1. **Analyze** — Classifies the site type (product, institutional, marketing, etc.)
2. **Extract** — Content script pulls visible text elements from the page
3. **Rewrite** — Claude rewrites each text block using conversion copywriting principles
4. **Apply** — Content script replaces text in the DOM

## Cost

Uses your own Claude API key. Typical rewrite costs $0.02-0.10 depending on page size.

## Limitations

- Only rewrites visible text (not images, videos, or dynamically loaded content)
- Some sites with heavy JavaScript may not extract properly
- Rate limited by your Anthropic API tier

## Files

```
├── manifest.json     # Chrome extension config
├── popup.html        # Extension popup UI
├── popup.js          # Main logic (API calls, prompt engineering)
├── content.js        # DOM extraction and text replacement
└── README.md
```

## License

MIT — do whatever you want with it.
