// Popup script for AI Page Rewriter
// Handles preset modes, user context, site context, and communication with content script

// ============================================================
// API KEY MANAGEMENT
// ============================================================

let ANTHROPIC_API_KEY = "";

async function loadApiKey() {
  return new Promise((resolve) => {
    chrome.storage.local.get(["anthropicApiKey"], (result) => {
      ANTHROPIC_API_KEY = result.anthropicApiKey || "";
      resolve(ANTHROPIC_API_KEY);
    });
  });
}

async function saveApiKey(key) {
  return new Promise((resolve) => {
    chrome.storage.local.set({ anthropicApiKey: key }, () => {
      ANTHROPIC_API_KEY = key;
      resolve();
    });
  });
}

// ============================================================
// SITE CONTEXT CACHE
// Stores classification per domain to avoid repeated API calls
// ============================================================

const siteContextCache = new Map();

// ============================================================
// SYSTEM PROMPT
// Senior copywriter instructions for radical improvement
// ============================================================

const SYSTEM_PROMPT = `You are a senior product and brand copywriter.

Your task is to radically improve the clarity, sharpness, and persuasive power of an existing webpage by rewriting its visible text IN PLACE.

This is NOT a light edit.

You should:
- Re-author headlines, subheadings, and body copy when they are vague, generic, institutional, or self-referential
- Replace abstract language with concrete meaning
- Reduce mission-speak, platitudes, and circular phrasing
- Make strong, confident claims when appropriate
- Optimize for comprehension, memorability, and impact

You are allowed to:
- Change sentence structure entirely
- Shorten or expand text if it improves understanding
- Introduce clearer framing, benefits, or positioning
- Rewrite headlines aggressively if they are weak

You must:
- Preserve the existing DOM structure and hierarchy
- Keep text length roughly appropriate for its location (headline vs paragraph vs nav)
- Preserve meaning and factual correctness
- Preserve proper nouns, brand names, and claims that appear factual
- Preserve navigation labels unless explicitly told otherwise

VERY IMPORTANT:
- Do NOT merely paraphrase line-by-line
- If the original text is already strong, you may still improve specificity or punch
- Avoid adding marketing fluff; prefer sharp, plain language

Before writing, infer the organization's purpose, audience, and tone from:
- The domain name
- The surrounding page content
- The language used elsewhere on the page

Then write as if you were hired to improve this page, not to politely edit it.

Output ONLY the rewritten text segments, mapped exactly to the original elements.`;

// ============================================================
// PRESET DEFINITIONS
// One preset is selected per rewrite
// ============================================================

const PRESET_MODES = {
  clarity: `Rewrite to maximize immediate understanding.
Assume the reader asks: "What does this actually let me do?"
Prefer concrete actions over abstract positioning.
Remove marketing filler and vague phrasing.
Foreground the most useful information first.`,

  blended: `Rewrite to balance clarity and engagement.
Assume the reader is skimming.
Keep credibility high while making the value obvious.
Avoid hype, but do not be dry.
Reframe vague headlines into specific, helpful ones.`,

  formal: `Rewrite for a professional, risk-aware audience.
Assume limited time and low tolerance for ambiguity.
Use precise language.
Replace slogans with concrete descriptions.`,

  informal: `Rewrite to sound natural and direct.
Assume a knowledgeable but non-expert reader.
Reduce stiffness and corporate phrasing.
Avoid jargon where simpler words work.
Make it sound like a helpful person explaining, not a brand talking.`,

  hype: `Rewrite to emphasize momentum and excitement.
Assume the reader wants to feel energy and possibility.
Highlight outcomes and transformation.
Use active, forward-moving language.
Do NOT exaggerate facts or invent claims.`,
  
  conversion: `Rewrite to maximize action-taking.
Assume the reader asks: "Why should I care? What's in it for me?"
Lead with outcomes and transformation.
Handle objections before they arise.
Make the next step obvious and low-friction.`,

  trust: `Rewrite to maximize credibility.
Assume the reader has been burned before.
Prefer specific claims over impressive ones.
Show proof, not promises.
Acknowledge complexity where appropriate.`,
};

// ============================================================
// SITE CONTEXT DETECTION
// Classifies the website before rewriting
// ============================================================

/**
 * Extract page signals for site classification
 * Uses chrome.scripting to get signals from the active tab
 */
async function extractPageSignals() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) throw new Error("No active tab found");

  const results = await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: () => {
      // Extract signals available on the current page
      const domain = window.location.hostname;
      const title = document.title || "";
      const metaDesc =
        document.querySelector('meta[name="description"]')?.content || "";
      
      // Get top-level navigation labels
      const navLabels = [];
      const navElements = document.querySelectorAll(
        "nav a, header a, [role='navigation'] a"
      );
      navElements.forEach((el) => {
        const text = el.innerText?.trim();
        if (text && text.length < 30 && navLabels.length < 10) {
          navLabels.push(text);
        }
      });

      // Get hero headline (first H1)
      const heroHeadline =
        document.querySelector("h1")?.innerText?.trim() || "";

      return {
        domain,
        title,
        metaDescription: metaDesc,
        navLabels: [...new Set(navLabels)].slice(0, 8),
        heroHeadline,
      };
    },
  });

  return results[0]?.result || null;
}

/**
 * Call Claude to classify the site
 * Returns structured classification only
 */
async function classifySite(signals) {
  const classificationPrompt = `Classify this website based on the following signals.
Return ONLY valid JSON with no additional text.

Domain: ${signals.domain}
Page Title: ${signals.title}
Meta Description: ${signals.metaDescription}
Navigation Labels: ${signals.navLabels.join(", ")}
Hero Headline: ${signals.heroHeadline}

Return exactly this JSON shape:
{
  "site_type": "institutional | product | documentation | marketing | media",
  "primary_goal": "signal values | explain product | drive action | inform",
  "rewrite_constraint": "conservative | balanced | aggressive"
}

Choose ONE value for each field. No explanations.`;

  console.log("=== SITE CLASSIFICATION ===");
  console.log("Signals:", signals);

  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": ANTHROPIC_API_KEY,
      "anthropic-version": "2023-06-01",
      "anthropic-dangerous-direct-browser-access": "true",
    },
    body: JSON.stringify({
      model: "claude-sonnet-4-20250514",
      max_tokens: 256,
      messages: [{ role: "user", content: classificationPrompt }],
    }),
  });

  if (!response.ok) {
    console.warn("Site classification failed, using defaults");
    return getDefaultSiteContext();
  }

  const data = await response.json();
  const text = data.content[0]?.text || "";

  try {
    // Extract JSON from response (handle potential markdown code blocks)
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      const parsed = JSON.parse(jsonMatch[0]);
      console.log("Site classification:", parsed);
      return {
        site_type: parsed.site_type || "marketing",
        primary_goal: parsed.primary_goal || "drive action",
        rewrite_constraint: parsed.rewrite_constraint || "balanced",
      };
    }
  } catch (e) {
    console.warn("Failed to parse classification:", e);
  }

  return getDefaultSiteContext();
}

/**
 * Default site context when classification fails
 */
function getDefaultSiteContext() {
  return {
    site_type: "marketing",
    primary_goal: "drive action",
    rewrite_constraint: "balanced",
  };
}

/**
 * Get or create site context for a domain
 * Caches results to avoid repeated API calls
 */
async function getSiteContext(domain) {
  if (siteContextCache.has(domain)) {
    console.log("Using cached site context for:", domain);
    return siteContextCache.get(domain);
  }

  const signals = await extractPageSignals();
  if (!signals) {
    return getDefaultSiteContext();
  }

  const context = await classifySite(signals);
  siteContextCache.set(domain, context);
  return context;
}

/**
 * Generate site context block for the prompt
 */
function buildSiteContextBlock(siteContext) {
  const typeDescriptions = {
    institutional: "This is an institutional website.\nPrimary purpose is to express mission and values.\nYou may reframe for clarity but preserve core identity.",
    product: "This is a product website.\nPrimary purpose is to explain what the product does.\nFraming shifts are allowed for clarity.",
    documentation: "This is a documentation website.\nPrimary purpose is to inform and instruct.\nPrioritize clarity and compression.",
    marketing: "This is a marketing website.\nPrimary purpose is to drive user action.\nFraming shifts are allowed if more concrete.",
    media: "This is a media or content website.\nPrimary purpose is to inform readers.\nPrioritize clarity and compression.",
  };

  const constraintDescriptions = {
    conservative: "Rewriting should be moderate.\nImprove clarity but don't completely reframe.",
    balanced: "Rewriting should be balanced.\nModerate reframing is acceptable.\nHeadlines may be improved if more concrete.",
    aggressive: "Rewriting can be aggressive.\nSignificant reframing is allowed.\nHeadlines may be replaced entirely if clearer.",
  };

  const typeDesc = typeDescriptions[siteContext.site_type] || typeDescriptions.marketing;
  const constraintDesc = constraintDescriptions[siteContext.rewrite_constraint] || constraintDescriptions.balanced;

  return `SITE CONTEXT:
${typeDesc}
${constraintDesc}`;
}

// ============================================================
// PROMPT BUILDER
// Constructs the full prompt from system + site context + preset + user context
// ============================================================

/**
 * Build the complete prompt for the LLM
 * @param {string} presetKey - The selected preset mode key
 * @param {string} userContext - Optional user-provided context
 * @param {object} siteContext - Site classification result
 * @returns {object} - Prompt configuration object
 */
function buildPrompt(presetKey, userContext, siteContext) {
  const presetInstructions = PRESET_MODES[presetKey] || PRESET_MODES.clarity;
  const trimmedContext = userContext?.trim() || "";

  // Construct full system prompt with all sections
  let fullPrompt = `SYSTEM:\n${SYSTEM_PROMPT}`;

  // Add site context block ABOVE preset
  if (siteContext) {
    fullPrompt += `\n\n${buildSiteContextBlock(siteContext)}`;
  }

  fullPrompt += `\n\nPRESET:\n${presetInstructions}`;

  if (trimmedContext) {
    fullPrompt += `\n\nUSER CONTEXT (optional, verbatim):\n${trimmedContext}`;
  } else {
    fullPrompt += `\n\nUSER CONTEXT (optional, verbatim):`;
  }

  return {
    systemPrompt: fullPrompt,
    presetKey,
    userContext: trimmedContext || null,
    siteContext,
  };
}

// ============================================================
// LLM API CALL - CLAUDE (ANTHROPIC)
// ============================================================

/**
 * Call the Claude API to rewrite text
 *
 * @param {Array} textElements - Array of { index, tagName, text }
 * @param {object} promptConfig - { systemPrompt, presetKey, userContext, siteContext }
 * @returns {Promise<Array>} - Array of { index, text } with rewritten content
 */
async function callLLM(textElements, promptConfig) {
  console.log("=== CLAUDE API CALL ===");
  console.log("System prompt:\n", promptConfig.systemPrompt);
  console.log("Preset:", promptConfig.presetKey);
  console.log("User context:", promptConfig.userContext);
  console.log("Site context:", promptConfig.siteContext);

  // Format content blocks for the LLM
  // Each block includes index so Claude can return them in order
  const contentBlocksStr = textElements
    .map(({ index, tagName, text }) =>
      `[${index}][${tagName}] ${text}`
    )
    .join("\n\n---\n\n");

  const userMessage = `Rewrite each text block below. Return the rewritten text in the same format: [index][tag] rewritten text

Separate each block with ---

${contentBlocksStr}`;

  console.log("User message:\n", userMessage);

  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": ANTHROPIC_API_KEY,
      "anthropic-version": "2023-06-01",
      "anthropic-dangerous-direct-browser-access": "true",
    },
    body: JSON.stringify({
      model: "claude-sonnet-4-20250514",
      max_tokens: 8192,
      system: promptConfig.systemPrompt,
      messages: [
        { role: "user", content: userMessage }
      ],
    }),
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    console.error("API error:", errorData);
    throw new Error(errorData.error?.message || `API error: ${response.status}`);
  }

  const data = await response.json();
  console.log("Claude response:", data);

  const rewrittenContent = data.content[0].text;

  // Parse the response back into { index, text } format
  return parseRewrittenContent(rewrittenContent, textElements);
}

/**
 * Parse Claude's response back into { index, text } array
 * Expected format: [index][tag] rewritten text, separated by ---
 */
function parseRewrittenContent(content, originalElements) {
  const results = [];
  const blocks = content.split(/\n*---\n*/);

  for (const block of blocks) {
    const trimmed = block.trim();
    if (!trimmed) continue;

    // Match [index][tag] text pattern
    const match = trimmed.match(/^\[(\d+)\]\[([^\]]+)\]\s*([\s\S]*)$/);
    if (match) {
      const index = parseInt(match[1], 10);
      const text = match[3].trim();
      results.push({ index, text });
    }
  }

  // If parsing failed, fall back to original text
  if (results.length === 0) {
    console.warn("Failed to parse Claude response, returning originals");
    return originalElements.map(({ index, text }) => ({ index, text }));
  }

  // Ensure all original indices are covered
  const resultIndices = new Set(results.map((r) => r.index));
  for (const el of originalElements) {
    if (!resultIndices.has(el.index)) {
      results.push({ index: el.index, text: el.text });
    }
  }

  return results.sort((a, b) => a.index - b.index);
}

// ============================================================
// UI ELEMENTS AND STATE
// ============================================================

const apiKeyInput = document.getElementById("apiKey");
const saveApiKeyBtn = document.getElementById("saveApiKey");
const apiKeyStatus = document.getElementById("apiKeyStatus");
const presetModeSelect = document.getElementById("presetMode");
const userContextTextarea = document.getElementById("userContext");
const rewriteBtn = document.getElementById("rewriteBtn");
const resetBtn = document.getElementById("resetBtn");
const statusEl = document.getElementById("status");

let isProcessing = false;

// ============================================================
// HELPER FUNCTIONS
// ============================================================

/**
 * Update the status message in the popup
 */
function setStatus(message, type = "info") {
  statusEl.className = type;
  statusEl.innerHTML = message;
}

function updateApiKeyStatus() {
  if (ANTHROPIC_API_KEY) {
    const masked = ANTHROPIC_API_KEY.slice(0, 10) + "..." + ANTHROPIC_API_KEY.slice(-4);
    apiKeyStatus.textContent = `Saved: ${masked}`;
    apiKeyStatus.className = "api-key-status saved";
    setStatus("Ready to rewrite.", "info");
  } else {
    apiKeyStatus.textContent = "No API key saved";
    apiKeyStatus.className = "api-key-status";
    setStatus("Enter your API key to get started.", "info");
  }
}

/**
 * Send a message to the content script in the active tab
 */
async function sendToContentScript(message) {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  if (!tab?.id) {
    throw new Error("No active tab found");
  }

  return new Promise((resolve, reject) => {
    chrome.tabs.sendMessage(tab.id, message, (response) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else {
        resolve(response);
      }
    });
  });
}

/**
 * Get the domain from the active tab
 */
async function getActiveDomain() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.url) return null;
  try {
    return new URL(tab.url).hostname;
  } catch {
    return null;
  }
}

/**
 * Set the processing state and update UI states
 */
function setProcessing(processing) {
  isProcessing = processing;
  rewriteBtn.disabled = processing || !ANTHROPIC_API_KEY;
  resetBtn.disabled = processing;
  presetModeSelect.disabled = processing;
  userContextTextarea.disabled = processing;
}

// ============================================================
// BUTTON HANDLERS
// ============================================================

/**
 * Handle API key save
 */
saveApiKeyBtn.addEventListener("click", async () => {
  const key = apiKeyInput.value.trim();
  if (!key) {
    setStatus("Please enter an API key.", "error");
    return;
  }

  await saveApiKey(key);
  apiKeyInput.value = "";
  updateApiKeyStatus();
  rewriteBtn.disabled = false;
});

/**
 * Handle "Rewrite Page" button click
 */
async function handleRewrite() {
  if (isProcessing) return;

  if (!ANTHROPIC_API_KEY) {
    setStatus("Please save your API key first.", "error");
    return;
  }

  try {
    setProcessing(true);

    // Step 1: Get site context
    const domain = await getActiveDomain();
    setStatus('<span class="spinner"></span> Analyzing site...', "info");
    
    let siteContext = null;
    if (domain) {
      siteContext = await getSiteContext(domain);
    }

    setStatus('<span class="spinner"></span> Extracting text...', "info");

    // Get selected preset and user context
    const presetKey = presetModeSelect.value;
    const userContext = userContextTextarea.value;

    // Build the prompt with site context
    const promptConfig = buildPrompt(presetKey, userContext, siteContext);

    // Step 2: Extract text from the page
    const extractResponse = await sendToContentScript({ action: "extractText" });

    if (!extractResponse?.success || !extractResponse.elements?.length) {
      setStatus("No text elements found on this page.", "error");
      setProcessing(false);
      return;
    }

    const elementCount = extractResponse.elements.length;
    setStatus(
      `<span class="spinner"></span> Rewriting ${elementCount} elements...`,
      "info"
    );

    // Step 3: Call the LLM to rewrite the text
    const rewrittenTexts = await callLLM(extractResponse.elements, promptConfig);

    setStatus('<span class="spinner"></span> Applying changes...', "info");

    // Step 4: Send rewritten text back to content script
    const replaceResponse = await sendToContentScript({
      action: "replaceText",
      rewrittenTexts: rewrittenTexts,
    });

    if (replaceResponse?.success) {
      setStatus(`✓ Rewrote ${elementCount} elements`, "success");
    } else {
      setStatus("Failed to apply changes.", "error");
    }
  } catch (error) {
    console.error("Rewrite error:", error);
    if (error.message.includes("rate limit") || error.message.includes("rate_limit")) {
      setStatus("Rate limited. Wait 60s and try again.", "error");
    } else if (error.message.includes("Could not establish connection")) {
      setStatus("Refresh the page and try again.", "error");
    } else {
      setStatus(`Error: ${error.message}`, "error");
    }
  } finally {
    setProcessing(false);
  }
}

/**
 * Handle "Reset" button click
 */
async function handleReset() {
  if (isProcessing) return;

  try {
    setProcessing(true);
    setStatus('<span class="spinner"></span> Restoring...', "info");

    const response = await sendToContentScript({ action: "resetText" });

    if (response?.success) {
      setStatus("✓ Original text restored", "success");
    } else {
      setStatus("Failed to restore text.", "error");
    }
  } catch (error) {
    console.error("Reset error:", error);
    setStatus(`Error: ${error.message}`, "error");
  } finally {
    setProcessing(false);
  }
}

// ============================================================
// EVENT LISTENERS
// ============================================================

rewriteBtn.addEventListener("click", handleRewrite);
resetBtn.addEventListener("click", handleReset);

// ============================================================
// INITIALIZATION
// ============================================================

async function init() {
  await loadApiKey();
  updateApiKeyStatus();
  rewriteBtn.disabled = !ANTHROPIC_API_KEY;
}

init();
