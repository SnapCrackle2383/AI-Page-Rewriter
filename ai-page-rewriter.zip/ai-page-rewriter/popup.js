// AI Page Rewriter - Popup Script
// Rewrites webpage copy using Claude AI for better conversion and clarity

// ============================================================
// API KEY MANAGEMENT
// ============================================================

let ANTHROPIC_API_KEY = "";

async function loadApiKey() {
  return new Promise((resolve) => {
    chrome.storage.local.get(["anthropicApiKey"], (result) => {
      ANTHROPIC_API_KEY = result.anthropicApiKey || "";
      resolve(ANTHROPIC_API_KEY);
    });
  });
}

async function saveApiKey(key) {
  return new Promise((resolve) => {
    chrome.storage.local.set({ anthropicApiKey: key }, () => {
      ANTHROPIC_API_KEY = key;
      resolve();
    });
  });
}

// ============================================================
// MODEL CONFIGURATION
// ============================================================

const MODELS = {
  fast: "claude-haiku-4-5-20250929",
  main: "claude-sonnet-4-20250514",
};

// ============================================================
// CACHES
// ============================================================

const siteContextCache = new Map();
const researchCache = new Map();

// ============================================================
// RATE LIMIT HELPERS
// ============================================================

function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

// ============================================================
// SYSTEM PROMPT
// ============================================================

const SYSTEM_PROMPT = `You are a direct-response copywriter. Rewrite webpage text so more visitors take action.

## METHODOLOGY

For every piece of text, ask:
1. What does the visitor WANT?
2. What's STOPPING them?
3. Does this text ANSWER that or just make noise?

## BAD VS GOOD COPY

BAD: "We empower organizations to achieve operational excellence through innovative solutions."
GOOD: "Cut operating costs 30% by automating the workflows your team hates."

BAD: "A commitment to quality drives everything we do."
GOOD: "98% of orders ship within 24 hours. Miss it? Shipping is free."

BAD: "Our platform leverages cutting-edge AI technology."
GOOD: "Upload a document. Get a summary in 11 seconds."

## CONSTRAINTS

You MUST:
- Preserve DOM structure (same number of blocks out as in)
- Keep text length appropriate to placement
- Preserve proper nouns, brand names, factual claims

CRITICAL - FACTS:
- ONLY use statistics from the VERIFIED RESEARCH section
- No research stat? Use qualitative language ("thousands of" not "47,000")
- Never invent numbers

## OUTPUT FORMAT

[index][tagName] rewritten text

Separate blocks with ---`;

// ============================================================
// PRESET DEFINITIONS
// ============================================================

const PRESET_MODES = {
  conversion: `GOAL: Maximize action-taking.
Headlines: Lead with outcome. Kill vague descriptors.
Body: One idea per paragraph. Proof over claims.
CTAs: Specify what happens next.`,

  clarity: `GOAL: Maximize comprehension speed.
Headlines: Front-load important info. No wordplay.
Body: Short sentences. One concept each.
CTAs: Verb + object. Three words max.`,

  trust: `GOAL: Maximize credibility.
Headlines: Specific > impressive.
Body: Show your work. Name sources.
CTAs: Lower the stakes.`,

  emotion: `GOAL: Maximize resonance.
Headlines: Name the frustration or aspiration. Use "you."
Body: Paint before/after contrast. Use sensory language.
CTAs: Connect to identity.`,

  professional: `GOAL: Maximize authority.
Headlines: Lead with differentiation.
Body: Precise terminology. No hedging, no hype.
CTAs: Respect their process.`,
};

// ============================================================
// RESEARCH PHASE
// ============================================================

async function researchCompany(domain, pageTitle, heroHeadline) {
  if (researchCache.has(domain)) {
    console.log("Using cached research for:", domain);
    return researchCache.get(domain);
  }

  console.log("=== RESEARCHING COMPANY ===");

  const researchPrompt = `Find key facts about: ${domain}
Title: ${pageTitle || "Unknown"}

Return JSON only:
{
  "company_name": "name",
  "founded": "year or null",
  "stats": {
    "employees": "number or null",
    "customers": "number or null",
    "users": "number or null"
  },
  "achievements": ["top 3 max"],
  "key_differentiator": "one sentence"
}

Only include VERIFIED facts from search. Use null if not found.`;

  try {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
        "anthropic-dangerous-direct-browser-access": "true",
      },
      body: JSON.stringify({
        model: MODELS.fast,
        max_tokens: 800,
        tools: [{ type: "web_search_20250305", name: "web_search" }],
        messages: [{ role: "user", content: researchPrompt }],
      }),
    });

    if (!response.ok) {
      console.warn("Research API call failed:", response.status);
      return getDefaultResearch(domain);
    }

    const data = await response.json();

    let textContent = "";
    for (const block of data.content) {
      if (block.type === "text") {
        textContent += block.text;
      }
    }

    try {
      const jsonMatch = textContent.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        const research = JSON.parse(jsonMatch[0]);
        console.log("Parsed research:", research);
        researchCache.set(domain, research);
        return research;
      }
    } catch (e) {
      console.warn("Failed to parse research JSON:", e);
    }

    return getDefaultResearch(domain);
  } catch (error) {
    console.error("Research error:", error);
    return getDefaultResearch(domain);
  }
}

function getDefaultResearch(domain) {
  return {
    company_name: domain,
    founded: null,
    stats: { employees: null, customers: null, users: null },
    achievements: [],
    key_differentiator: null,
  };
}

function buildResearchBlock(research) {
  if (!research || !research.company_name) {
    return `## VERIFIED RESEARCH\nNo stats found. Use qualitative language only.`;
  }

  let block = `## VERIFIED RESEARCH: ${research.company_name}\n`;

  if (research.founded) block += `Founded: ${research.founded}\n`;

  const stats = research.stats || {};
  if (stats.employees) block += `Employees: ${stats.employees}\n`;
  if (stats.customers) block += `Customers: ${stats.customers}\n`;
  if (stats.users) block += `Users: ${stats.users}\n`;

  if (research.achievements?.length > 0) {
    block += `Achievements: ${research.achievements.join("; ")}\n`;
  }

  if (research.key_differentiator) {
    block += `Differentiator: ${research.key_differentiator}\n`;
  }

  block += `\nONLY use stats listed above. Don't invent numbers.`;
  return block;
}

// ============================================================
// SITE CONTEXT DETECTION
// ============================================================

async function extractPageSignals() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) throw new Error("No active tab found");

  const results = await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: () => {
      return {
        domain: window.location.hostname,
        title: document.title || "",
        heroHeadline: document.querySelector("h1")?.innerText?.trim() || "",
        metaDescription:
          document.querySelector('meta[name="description"]')?.content || "",
      };
    },
  });

  return results[0]?.result || null;
}

async function classifySite(signals) {
  const domain = signals.domain.toLowerCase();

  let visitor_goal = "understand what this offers and whether it's relevant";
  let page_purpose = "convert";
  let tone_baseline = "conversational";

  if (
    domain.includes(".edu") ||
    domain.includes("university") ||
    domain.includes("college")
  ) {
    visitor_goal = "decide if this school is right for them";
    page_purpose = "inform";
    tone_baseline = "inspirational";
  } else if (domain.includes(".gov")) {
    visitor_goal = "find specific information or services";
    page_purpose = "inform";
    tone_baseline = "formal";
  } else if (domain.includes("docs.") || domain.includes("documentation")) {
    visitor_goal = "learn how to do something specific";
    page_purpose = "educate";
    tone_baseline = "technical";
  }

  return { visitor_goal, page_purpose, tone_baseline, signals };
}

async function getSiteContext(domain) {
  if (siteContextCache.has(domain)) {
    return siteContextCache.get(domain);
  }

  const signals = await extractPageSignals();
  if (!signals) return null;

  const context = await classifySite(signals);
  siteContextCache.set(domain, context);
  return context;
}

function buildSiteContextBlock(siteContext) {
  return `## PAGE CONTEXT
Visitor goal: ${siteContext.visitor_goal}
Purpose: ${siteContext.page_purpose}
Tone: ${siteContext.tone_baseline}`;
}

// ============================================================
// PROMPT BUILDER
// ============================================================

function buildPrompt(presetKey, userContext, siteContext, research) {
  const presetInstructions = PRESET_MODES[presetKey] || PRESET_MODES.conversion;
  const trimmedContext = userContext?.trim() || "";

  let fullPrompt = SYSTEM_PROMPT;
  fullPrompt += `\n\n${buildResearchBlock(research)}`;

  if (siteContext) {
    fullPrompt += `\n\n${buildSiteContextBlock(siteContext)}`;
  }

  fullPrompt += `\n\n## OBJECTIVE\n${presetInstructions}`;

  if (trimmedContext) {
    fullPrompt += `\n\n## USER CONTEXT\n${trimmedContext}`;
  }

  return {
    systemPrompt: fullPrompt,
    presetKey,
    userContext: trimmedContext || null,
    siteContext,
    research,
  };
}

// ============================================================
// LLM API CALL
// ============================================================

async function callLLM(textElements, promptConfig) {
  console.log("=== REWRITE API CALL ===");

  const truncatedElements = textElements.map((el) => ({
    ...el,
    text: el.text.length > 500 ? el.text.slice(0, 500) + "..." : el.text,
  }));

  const contentBlocksStr = truncatedElements
    .map(({ index, tagName, text }) => `[${index}][${tagName}] ${text}`)
    .join("\n---\n");

  const userMessage = `Rewrite each block. Use ONLY verified stats. Output format: [index][tag] text

${contentBlocksStr}`;

  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": ANTHROPIC_API_KEY,
      "anthropic-version": "2023-06-01",
      "anthropic-dangerous-direct-browser-access": "true",
    },
    body: JSON.stringify({
      model: MODELS.main,
      max_tokens: 4096,
      system: promptConfig.systemPrompt,
      messages: [{ role: "user", content: userMessage }],
    }),
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    console.error("API error:", errorData);
    throw new Error(
      errorData.error?.message || `API error: ${response.status}`
    );
  }

  const data = await response.json();
  const rewrittenContent = data.content[0].text;
  return parseRewrittenContent(rewrittenContent, textElements);
}

function parseRewrittenContent(content, originalElements) {
  const results = [];
  const blocks = content.split(/\n*---\n*/);

  for (const block of blocks) {
    const trimmed = block.trim();
    if (!trimmed) continue;

    const match = trimmed.match(/^\[(\d+)\]\[([^\]]+)\]\s*([\s\S]*)$/);
    if (match) {
      const index = parseInt(match[1], 10);
      const text = match[3].trim();
      results.push({ index, text });
    }
  }

  if (results.length === 0) {
    return originalElements.map(({ index, text }) => ({ index, text }));
  }

  const resultIndices = new Set(results.map((r) => r.index));
  for (const el of originalElements) {
    if (!resultIndices.has(el.index)) {
      results.push({ index: el.index, text: el.text });
    }
  }

  return results.sort((a, b) => a.index - b.index);
}

// ============================================================
// UI ELEMENTS AND STATE
// ============================================================

const apiKeyInput = document.getElementById("apiKey");
const saveApiKeyBtn = document.getElementById("saveApiKey");
const apiKeyStatus = document.getElementById("apiKeyStatus");
const presetModeSelect = document.getElementById("presetMode");
const userContextTextarea = document.getElementById("userContext");
const rewriteBtn = document.getElementById("rewriteBtn");
const resetBtn = document.getElementById("resetBtn");
const statusEl = document.getElementById("status");
const skipResearchCheckbox = document.getElementById("skipResearch");

let isProcessing = false;
let lastRequestTime = 0;
const MIN_REQUEST_INTERVAL = 5000;

// ============================================================
// HELPER FUNCTIONS
// ============================================================

function setStatus(message, type = "info") {
  statusEl.className = type;
  statusEl.innerHTML = message;
}

function updateApiKeyStatus() {
  if (ANTHROPIC_API_KEY) {
    const masked = ANTHROPIC_API_KEY.slice(0, 10) + "..." + ANTHROPIC_API_KEY.slice(-4);
    apiKeyStatus.textContent = `Saved: ${masked}`;
    apiKeyStatus.className = "api-key-status saved";
    setStatus("Ready to rewrite.", "info");
  } else {
    apiKeyStatus.textContent = "No API key saved";
    apiKeyStatus.className = "api-key-status";
    setStatus("Enter your API key to get started.", "info");
  }
}

async function sendToContentScript(message) {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) throw new Error("No active tab found");

  return new Promise((resolve, reject) => {
    chrome.tabs.sendMessage(tab.id, message, (response) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else {
        resolve(response);
      }
    });
  });
}

async function getActiveDomain() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.url) return null;
  try {
    return new URL(tab.url).hostname;
  } catch {
    return null;
  }
}

function setProcessing(processing) {
  isProcessing = processing;
  rewriteBtn.disabled = processing || !ANTHROPIC_API_KEY;
  resetBtn.disabled = processing;
  presetModeSelect.disabled = processing;
  userContextTextarea.disabled = processing;
}

// ============================================================
// EVENT HANDLERS
// ============================================================

saveApiKeyBtn.addEventListener("click", async () => {
  const key = apiKeyInput.value.trim();
  if (!key) {
    setStatus("Please enter an API key.", "error");
    return;
  }

  await saveApiKey(key);
  apiKeyInput.value = "";
  updateApiKeyStatus();
  rewriteBtn.disabled = false;
});

async function handleRewrite() {
  if (isProcessing) return;

  if (!ANTHROPIC_API_KEY) {
    setStatus("Please save your API key first.", "error");
    return;
  }

  const now = Date.now();
  const timeSinceLastRequest = now - lastRequestTime;
  if (timeSinceLastRequest < MIN_REQUEST_INTERVAL) {
    const waitTime = Math.ceil(
      (MIN_REQUEST_INTERVAL - timeSinceLastRequest) / 1000
    );
    setStatus(`Wait ${waitTime}s before next rewrite`, "error");
    return;
  }

  try {
    setProcessing(true);
    lastRequestTime = Date.now();

    const domain = await getActiveDomain();
    setStatus('<span class="spinner"></span> Analyzing page...', "info");

    const siteContext = domain ? await getSiteContext(domain) : null;

    const skipResearch = skipResearchCheckbox?.checked ?? false;
    let research = getDefaultResearch(domain);

    if (!skipResearch) {
      setStatus('<span class="spinner"></span> Researching...', "info");

      research = await researchCompany(
        domain,
        siteContext?.signals?.title,
        siteContext?.signals?.heroHeadline
      );

      await delay(2000);
    }

    setStatus('<span class="spinner"></span> Extracting text...', "info");

    const presetKey = presetModeSelect.value;
    const userContext = userContextTextarea.value;
    const promptConfig = buildPrompt(
      presetKey,
      userContext,
      siteContext,
      research
    );

    const extractResponse = await sendToContentScript({ action: "extractText" });

    if (!extractResponse?.success || !extractResponse.elements?.length) {
      setStatus("No text elements found.", "error");
      setProcessing(false);
      return;
    }

    const maxElements = 40;
    const elements = extractResponse.elements.slice(0, maxElements);
    const elementCount = elements.length;

    setStatus(
      `<span class="spinner"></span> Rewriting ${elementCount} elements...`,
      "info"
    );

    const rewrittenTexts = await callLLM(elements, promptConfig);

    setStatus('<span class="spinner"></span> Applying...', "info");

    const replaceResponse = await sendToContentScript({
      action: "replaceText",
      rewrittenTexts: rewrittenTexts,
    });

    if (replaceResponse?.success) {
      const hasStats =
        research.stats?.employees ||
        research.stats?.customers ||
        research.stats?.users;
      const researchNote = skipResearch
        ? ""
        : hasStats
        ? " (with verified stats)"
        : "";
      setStatus(`✓ Rewrote ${elementCount} elements${researchNote}`, "success");
    } else {
      setStatus("Failed to apply changes.", "error");
    }
  } catch (error) {
    console.error("Rewrite error:", error);

    if (
      error.message.includes("rate limit") ||
      error.message.includes("rate_limit")
    ) {
      setStatus("Rate limited. Wait 60s and try again.", "error");
    } else if (error.message.includes("Could not establish connection")) {
      setStatus("Refresh the page and try again.", "error");
    } else {
      setStatus(`Error: ${error.message}`, "error");
    }
  } finally {
    setProcessing(false);
  }
}

async function handleReset() {
  if (isProcessing) return;

  try {
    setProcessing(true);
    setStatus('<span class="spinner"></span> Restoring...', "info");

    const response = await sendToContentScript({ action: "resetText" });

    if (response?.success) {
      setStatus("✓ Original text restored", "success");
    } else {
      setStatus("Failed to restore.", "error");
    }
  } catch (error) {
    console.error("Reset error:", error);
    setStatus(`Error: ${error.message}`, "error");
  } finally {
    setProcessing(false);
  }
}

rewriteBtn.addEventListener("click", handleRewrite);
resetBtn.addEventListener("click", handleReset);

// ============================================================
// INITIALIZATION
// ============================================================

async function init() {
  await loadApiKey();
  updateApiKeyStatus();
  rewriteBtn.disabled = !ANTHROPIC_API_KEY;
}

init();
